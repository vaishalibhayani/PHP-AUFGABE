<?php
session_start();

// Database connection settings
$servername = "localhost";
$db_username = "root";   // Change this to your database username
$db_password = "";       // Change this to your database password
$db_name = "login_system";  // The database you created earlier

// Create connection
$conn = new mysqli($servername, $db_username, $db_password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = md5($_POST['password']);  // MD5 hash (matches the one stored in the database)

    // Query to check username and password
    $sql = "SELECT id FROM users WHERE username = '$username' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Login successful
        $_SESSION['username'] = $username;
        header("Location: welcome.php");
    } else {
        // Login failed
        echo "Invalid username or password";
    }
}

$conn->close();
?>
