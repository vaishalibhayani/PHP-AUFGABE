<?php
session_start();
session_unset();  // Unset session variables
session_destroy();  // Destroy the session
header("Location: login.html");  // Redirect back to login page
?>
